package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Malladmin;
import com.example.services.MalladminServices;

@RestController
public class MalladminController {
	@Autowired 
	private MalladminServices service;
	
	
	@PostMapping("/entities")
	public Malladmin saveEntity(@RequestBody Malladmin Entity) {
		System.out.println(Entity);
    	return service.saveEntity(Entity);
		
	}
	@GetMapping("/entities")
    public List<Malladmin> fetchMalladminList() {
        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
		System.out.println();
        return service.fetchMalladminList();
    }
	@GetMapping("/entities/{id}")
    public Malladmin MalladminById(@PathVariable("id") Long id)
            {
        return service.MalladminById(id);
    }
	@DeleteMapping("/entities/{id}")
    public String deleteMalladminEntityId(@PathVariable("id") Long id) {
	  service.deleteMalladminId(id);
        return "Malladmin deleted Successfully!!";
    }
	
    }
 

