package com.example.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Malladmin;
import com.example.repository.MalladminRepository;

@Service
public class MalladminServiceImpl implements MalladminServices {
	@Autowired
	private MalladminRepository malladminRepository;

	@Override
	public Malladmin saveEntity(Malladmin entity) {
		// TODO Auto-generated method stub
		return malladminRepository.save(entity);
	}

	@Override
	public List<Malladmin> fetchMalladminList() {
		// TODO Auto-generated method stub
		return malladminRepository.findAll();
	}

	@Override
	public Malladmin MalladminById(Long id) {
		// TODO Auto-generated method stub
		return malladminRepository.findById(id).get();
	}

	@Override
	public void deleteMalladminId(Long id) {
		// TODO Auto-generated method stub
		malladminRepository.deleteById(id);
	}

	
	

}
