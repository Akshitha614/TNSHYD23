package com.example.services;

import java.util.List;

import com.example.entity.Malladmin;

public interface MalladminServices {

	Malladmin saveEntity(Malladmin entity);

	List<Malladmin> fetchMalladminList();

	Malladmin MalladminById(Long id);

	void deleteMalladminId(Long id);
	 
	


}
