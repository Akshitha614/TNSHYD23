package tns.approach1;

public class A {
	int a=10;
	static int b=20;
	int display() {
		return 10;
	}
	static void display1() {
			System.out.println(10);
			}
	public static void main(String[] args) {
		A a1=new A();
			System.out.println(a1.a);
			System.out.println(a1.display());
			System.out.println(A.b);
			A.display1();
	}
}

